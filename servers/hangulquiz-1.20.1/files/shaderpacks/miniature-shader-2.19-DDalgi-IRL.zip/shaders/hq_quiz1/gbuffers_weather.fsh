#version 430 compatibility
#define DDALGI_QUIZ1_IRL

#define OVERWORLD
#define DDALGI_QUIZ2_IRL

#include "/program/weather.fsh"