#version 430 compatibility
#define DDALGI_QUIZ1_IRL

#define OVERWORLD
#define DDALGI_QUIZ2_IRL
#define GBUFFERS_TERRAIN

#include "/program/textured_lit.vsh"