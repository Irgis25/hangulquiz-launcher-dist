#version 430 compatibility
#define DDALGI_QUIZ1_IRL
#include "/program/final.vsh"
