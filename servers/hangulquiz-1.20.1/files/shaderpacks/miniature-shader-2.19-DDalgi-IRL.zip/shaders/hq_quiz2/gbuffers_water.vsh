#version 430 compatibility

#define OVERWORLD
#define DDALGI_QUIZ2_IRL

#include "/program/translucent.vsh"