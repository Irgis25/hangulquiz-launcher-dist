#if MC_VERSION >= 1800
#version 430 compatibility

#define OVERWORLD
#define DDALGI_QUIZ2_IRL

#include "/program/skybasic.fsh"
#endif