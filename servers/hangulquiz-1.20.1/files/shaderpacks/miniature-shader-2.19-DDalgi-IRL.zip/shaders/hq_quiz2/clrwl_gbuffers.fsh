#version 430 compatibility

#define OVERWORLD
#define DDALGI_QUIZ2_IRL
#define GBUFFERS_TERRAIN
#define MOD_COLORWHEEL

#include "/program/textured_lit.fsh"