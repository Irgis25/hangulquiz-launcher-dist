#include "/shader.h"

uniform float screenBrightness;
uniform ivec2 eyeBrightnessSmooth;
uniform sampler2D gtexture;

varying float fogMix;
varying float reflectivity;
varying float waterTexStrength;
varying vec2 lightUV;
varying vec2 texUV;
varying vec3 feetPos;
varying vec3 gradientFogColor;
varying vec3 normal;
varying vec4 ambient;
varying vec4 color;

#if HAND_DYNAMIC_LIGHTING == 0
   uniform int heldBlockLightValue;
#elif HAND_DYNAMIC_LIGHTING == 1
   #define heldBlockLightValue 14
#endif

#ifdef VOXY
   varying float vanillaMix;
#endif

#include "/common/math.glsl"
#include "/common/getTorchColor.fsh"

#include "/common/transformations.glsl"

#ifdef DDALGI_QUIZ2_IRL
uniform float viewWidth;
uniform float viewHeight;
#define RENDER_SCALE vec2(1.0)
#define IRLITE_SURFACE_PASS
#include "/common/irlite_lights.glsl"
#endif

void main() {
   if (fogMix > 0.999) {
      discard;
   }

   vec4 albedo  = texture2D(gtexture, texUV);
   vec4 ambient = ambient;
   vec4 color   = color;

   #ifdef VOXY
      vec4 vanilla = albedo * color * ambient;
   #endif

   if (reflectivity > WATER_REFLECTIVITY - 0.01) {
      #if MC_VERSION >= 11300
         albedo.rgb = rescale(albedo.rgb * waterTexStrength, vec3(WATER_GLINT_CUTOFF), vec3(1.0));
         albedo.rgb = vec3(WATER_BRIGHTNESS) + WATER_GLINT_BRIGHTNESS * albedo.rgb;

         #define WATER_BUFFER color
      #else
         #define WATER_BUFFER albedo
      #endif

      WATER_BUFFER.ba = min(WATER_BUFFER.ba, vec2(max(WATER_BUFFER.r, WATER_BUFFER.g)*WATER_B, WATER_A));
   }

   ambient.rgb += getTorchColor(lightUV.s, ambient.rgb, feetPos);

   vec3 hqSurfaceTint = albedo.rgb * color.rgb;
   albedo *= color * ambient;

#ifdef DDALGI_QUIZ2_IRL
   vec3 hqDiffuse, hqSpecular;
   #ifdef DDALGI_IRL_ENTITY
      bool hqIsEntity = true;
   #else
      bool hqIsEntity = false;
   #endif
   irlite_lightSurface(feetPos, eye2view(screen2ndc(normal)),
                       feet2view(feetPos), hqIsEntity, 0u, hqDiffuse, hqSpecular);
   // Miniature's native colour/ambient path is kept. Add only local IRL light.
   albedo.rgb += hqSurfaceTint * IRLITE_INTENSITY_LIVE * hqDiffuse;
   albedo.rgb += 0.12 * IRLITE_INTENSITY_LIVE * IRLITE_SPECULAR_INTENSITY_LIVE * hqSpecular;
#endif


   #ifdef VOXY
      float reflectivity = mix(reflectivity, 0.0, vanillaMix);

      albedo = mix(albedo, vanilla, vanillaMix);
   #endif

   albedo.rgb = mix(albedo.rgb, gradientFogColor, fogMix);

   /* DRAWBUFFERS:067 */
   gl_FragData[0] = albedo;
   gl_FragData[1] = vec4(normal, 1.0);
   gl_FragData[2] = vec4(reflectivity, 0.0, 0.5, 1.0);
}