#include "/shader.h"

uniform float far;
uniform int isEyeInWater;
uniform sampler2D colortex0;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"
#include "/common/getReflectionColor.fsh"

#ifdef DDALGI_QUIZ2_IRL
uniform sampler2D colortex8;
uniform float viewWidth;
uniform float viewHeight;
vec3 hqBeamUpsample(vec2 uv) {
    vec2 sz = vec2(textureSize(colortex8, 0));
    vec2 p = uv * sz - 0.5;
    vec2 base = floor(p), f = fract(p);
    float depth = texture2D(depthtex0, uv).r;
    float fullDist = length(screen2view(uv, depth));
    vec3 sum = vec3(0.0); float weight = 0.0;
    for (int y = 0; y < 2; ++y) for (int x = 0; x < 2; ++x) {
        vec2 q = (base + vec2(x,y) + 0.5) / sz;
        vec4 sampleBeam = texture2D(colortex8, q);
        float bilinear = (x == 0 ? 1.0-f.x : f.x) * (y == 0 ? 1.0-f.y : f.y);
        float w = bilinear / (1.0 + 4.0 * abs(sampleBeam.a - fullDist));
        sum += sampleBeam.rgb * w; weight += w;
    }
    return sum / max(weight, 1e-6);
}
#endif
void main() {
   vec4 color = texture2D(colortex0, texUV);
   vec4 reflectivityAndRoughness = texture2D(colortex7, texUV);
   float reflectivity = reflectivityAndRoughness.x;
   float roughness = reflectivityAndRoughness.y;

   if (reflectivity > MIN_REFLECTIVITY && abs(reflectivityAndRoughness.z - 0.5) < 0.01) {
      // the normal doesn't come premultiplied by the normal matrix to
      // avoid the modelview transformations when view bobbing is on
      // which causes severe artifacts when moving
      vec3 prenormal = screen2ndc(texture2D(colortex6, texUV).xyz);

      #if WATER_WAVE_SIZE > 0

         if ((abs(prenormal.x) > 0.0 || abs(prenormal.z) > 0.0) && abs(prenormal.y) > 0.3333) {
            prenormal.xyz *= 1.0 / prenormal.y;
            prenormal.xz *= 0.01 * WATER_WAVE_SIZE;
         }

      #endif

      float depth  = texture2D(depthtex0, texUV).x;
      vec3 normal  = eye2view(prenormal);
      vec3 viewPos = screen2view(texUV, depth);
      vec3 feetPos = view2feet(viewPos);
      vec3 worldPos = feet2world(feetPos);
      float pixelDistance = min(1.0, length(feetPos)/16.0);
      float stepSize = stepify(mix(1.0/512.0, 1.0/64.0, pixelDistance), 1.0/512.0);

      normal += roughness * random3(stepify(worldPos, stepSize));
      normal = normalize(normal);

      vec4 reflectionColor = getReflectionColor(depth, normal, viewPos);

      color.rgb = mix(
         color.rgb,
         reflectionColor.rgb,
         reflectionColor.a * reflectivity * 0.1*REFLECTIONS
      );
   }

#ifdef DDALGI_QUIZ2_IRL
   vec3 hqBeam = HQ_IRL_BEAM_GAIN * hqBeamUpsample(texUV);
   // A restrained additive overlay preserves Miniature's existing bright set.
   color.rgb += hqBeam / (vec3(1.0) + hqBeam);
#endif
   gl_FragData[0] = color;
}