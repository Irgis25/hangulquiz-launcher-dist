#version 430 compatibility
#define DDALGI_LOBBY_IRL

#define OVERWORLD
#define DDALGI_QUIZ2_IRL
#define DDALGI_IRL_ENTITY
#define GBUFFERS_HAND

#include "/program/textured_lit.fsh"