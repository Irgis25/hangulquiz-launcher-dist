#version 430 compatibility
#define DDALGI_LOBBY_IRL
// Half-resolution, scene-depth-clipped IRL volume, with the mod's shadow atlas.
uniform sampler2D depthtex0;
uniform sampler2D noisetex;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform int frameCounter;
uniform float far;
varying vec2 texUV;
#include "/common/transformations.glsl"
#define RENDER_SCALE vec2(1.0)
#define IRLITE_VL_PASS
#include "/common/irlite_lights.glsl"
/*
const int colortex8Format = RGBA16F;
*/
const bool colortex8Clear = true;
const vec4 colortex8ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
void main() {
    float depth = texture2D(depthtex0, texUV).r;
    vec3 start = gbufferModelViewInverse[3].xyz;
    vec3 end = screen2feet(texUV, depth);
    vec3 delta = end - start;
    float len = length(delta);
    vec3 beam = vec3(0.0);
    if (len > 0.01) {
        float noise = fract(sin(dot(gl_FragCoord.xy + float(frameCounter % 8), vec2(12.9898,78.233))) * 43758.5453);
        beam = irlite_volumetric(start, end, delta / len, noise, texUV);
    }
    /* RENDERTARGETS: 8 */
    gl_FragData[0] = vec4(beam, len);
}
