#version 430 compatibility
#define DDALGI_LOBBY_IRL
#include "/program/final.vsh"
