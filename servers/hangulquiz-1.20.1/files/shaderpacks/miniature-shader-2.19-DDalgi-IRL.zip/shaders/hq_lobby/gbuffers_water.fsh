#version 430 compatibility
#define DDALGI_LOBBY_IRL

#define OVERWORLD
#define DDALGI_QUIZ2_IRL

#include "/program/translucent.fsh"